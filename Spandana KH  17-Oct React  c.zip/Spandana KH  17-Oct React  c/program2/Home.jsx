import React from 'react'
import { useNavigate } from 'react-router-dom';

function Home() {
    const navigate = useNavigate();
function handleLogin(){
    console.log("Home page Button clicked");
    navigate('/contact')
}
  return (
    <div>
      <h1>This is the Home Page</h1>
      <button onClick={handleLogin}>Login</button>
     
    </div>
  )
}


export default Home
