import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './Home'
import Contact from './Contact'
import About from './About'
import Index from './Index'

function App() {
  return (
    <div>
      <h1>This is App File</h1>
      <BrowserRouter>
      <Routes>
        <Route path='/' element ={<Index />} />
        <Route path='/home' element ={<Home />} />
        <Route path='/contact' element ={<Contact />} />
        <Route path='/about' element ={<About />} />
      </Routes>
      </BrowserRouter>
     

    </div>
  )
}

export default App
