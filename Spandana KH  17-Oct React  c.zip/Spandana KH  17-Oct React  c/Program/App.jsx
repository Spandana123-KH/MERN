
import './App.css'
/*import Hook from './Hook'
import Counter from './Counter'
import Cleanup from './Cleanup'
import UsersList from './UsersList'
import { Greeting } from './CSS'
import { Temperature } from './CSS'*/
import External from './External'
import Button from './Button'

import StyledComponents from './Styledcomponents'

function App() {
  return (
      <div>
        {/*<Hook/>
        <Counter/>
        <Cleanup/> 
        <UsersList/>
        <Greeting/>
        <Temperature/>*/}
        <External />
        <Button />
        <StyledComponents />
      </div>
      
  )
}

export default App