import styled from "styled-components";
import React from 'react';
function StyledComponents(){
    const Card=styled.div`
    background-color:Pink;
    border-radius:10px;
    padding:20px;
    text-align:center;
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
    `;
const Title=styled.h3`
color:#333;
`;
return(
    <Card>
        <Title>Product Name</Title>
        <p>$25.99</p>
        </Card>
);
}
export default StyledComponents;