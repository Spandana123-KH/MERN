import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import hello from './helloWorld'

function App() {
 
  return (
   <div>
     <h1>Hello World</h1>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Commodi odio dignissimos, sint blanditiis animi ullam! Quasi atque quos dolorem totam delectus, adipisci ex inventore odio quis consectetur fuga veritatis molestiae.</p>
    <hello />
   </div>
  )
}

export default App
