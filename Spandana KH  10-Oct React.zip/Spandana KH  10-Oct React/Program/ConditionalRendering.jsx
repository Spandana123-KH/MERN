import React from 'react';

function Pass() {
  return (
    <div><h1>Congratulations!</h1></div>
  );
}

function Fail() {
  return (
    <div><h1>Better Luck Next Time!</h1></div>
  );
}

//function Check(props) {
  //const isresult = props.isresult;  
//   if (isresult === "True")
//    {
//     return <Pass />;
//   }
//   if(isresult =="Fail"){
//   return <Fail />;
// }

 //}
 function ClassResult(props){
    const isresult = props.isresult;
    return(
        <>
        { isresult ? <Pass/>: <Fail/>}
        </>
    );
 }
export default ClassResult;


