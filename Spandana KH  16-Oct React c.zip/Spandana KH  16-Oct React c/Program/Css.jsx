const style={
    backgroundColor:"lightblue",
    padding:"10px",
    borderRadius:"5px",
};

function Greeting() {
    return <h2 style={style}>Hello Inline Styling!</h2>
}

function Temperature({value}){
    return(
        <p style={{color:value>30?"red":"blue"}}>
            Temperature:{value}°C
        </p>
    );
}

export { Greeting, Temperature };