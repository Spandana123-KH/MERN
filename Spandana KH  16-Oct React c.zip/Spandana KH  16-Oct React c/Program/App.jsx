import { useState } from 'react'
import Hook from './Hook'
import Counter from './Counter'
import Cleanup from './Cleanup'
import UsersList from './Userslist'
import {Greeting} { Temperature } from './Css'


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
       <Hook />
       <Counter />
       <Cleanup />
      <UsersList />
      <Greeting />
      <Temperature />
      </div>
      
    </>
  )
}

export default App
