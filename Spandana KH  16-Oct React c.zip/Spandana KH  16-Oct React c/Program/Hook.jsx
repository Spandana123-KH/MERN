import React,{ useEffect} from 'react';

function Hook() {
    useEffect(() =>{
        console.log("Component rendered or updated!");
    });
  return <h2> Hello React useEffect</h2>
 
};


export default Hook;
