import {useRef} from 'react'

function AccessingDom() {
    const inputElement = useRef();

    const focuseInput =() =>{
        inputElement.current.focuse();
    }
  return (
    <>
      <input type="text" ref={inputElement} />
      <button onClick={focuseInput}>Focus Input</button>
    </>
  );
}

export default AccessingDom;