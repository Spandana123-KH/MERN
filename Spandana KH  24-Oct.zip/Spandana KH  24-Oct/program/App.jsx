import React from 'react'

import Counter from './Counter';
import Render from './Render';
import WithUseMemo from './WithUseMemo';
import Parent from './Child';

import CounterApp from './CounterApp';

function App() {
  return (
    <div>
      <Counter />
      <Render />
      <WithUseMemo />
      <Parent />
     
      <CounterApp />
    </div>
  )
}

export default App;