import React,{useState,useMemo} from "react";

function UseMemo(){
    const [count,setCount]=useState(0);
    function slowCalculation(num){
        console.log("Running slow calculation...");
        for(let i=0; i<1000000000;i++){}
        return num*2;
    }
    const result=useMemo(()=>slowCalculation(count),[count]);
    console.log(count);
    return(
        <div>
            <h3>Slow result: {result}</h3>
            <button onClick={()=>setCount(count+1)}>Increment</button>
        </div>
    )
}
export default UseMemo;